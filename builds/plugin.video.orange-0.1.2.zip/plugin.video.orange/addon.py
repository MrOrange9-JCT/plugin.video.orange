import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, "movies")

url = "D:\Plex\Películas\Matrix (1999)\Matrix 1 - H265.mp4"
li = xbmcgui.ListItem("Matrix [COLOR blue](1999)[/COLOR]")
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)